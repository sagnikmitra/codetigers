<?php 

/*
|--------------------------------------------------------------------------
| Google Analytics
|--------------------------------------------------------------------------
| Google Analytics UACCT value
| If this value == Nothing, then nothing will be inserted into the view
| Used in google_helper
*/

$config['google_uacct'] = "";
$config['google_maps_api_key'] = "";

/* End of file strings.php */
/* Location: ./application/config/google.php */