<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

/* load the Fuel_Router class */
require FUEL_PATH."core/Router.php";

class MY_Router extends Fuel_Router {}