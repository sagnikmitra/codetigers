<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

/* load the MX_Loader class */
require FUEL_PATH."core/Loader.php";

class MY_Loader extends Fuel_Loader {}